/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package userPojo;

import java.sql.Date;

/**
 *
 * @author HP
 */
public class PatientPojo {

    public PatientPojo() {
    }
      public String getPid() {
        return Pid;
    }

    public void setPid(String Pid) {
        this.Pid = Pid;
    }

    public String getFname() {
        return Fname;
    }

    public void setFname(String Fname) {
        this.Fname = Fname;
    }

    public String getSname() {
        return Sname;
    }

    public void setSname(String Sname) {
        this.Sname = Sname;
    }

    public String getGender() {
        return Gender;
    }

    public void setGender(String Gender) {
        this.Gender = Gender;
    }

    public String getMstatus() {
        return Mstatus;
    }

    public void setMstatus(String Mstatus) {
        this.Mstatus = Mstatus;
    }

    public String getAddress() {
        return Address;
    }

    public void setAddress(String Address) {
        this.Address = Address;
    }

    public String getCity() {
        return City;
    }

    public void setCity(String City) {
        this.City = City;
    }

    public String getPhoneNo() {
        return PhoneNo;
    }

    public void setPhoneNo(String PhoneNo) {
        this.PhoneNo = PhoneNo;
    }

    public String getDoctorid() {
        return Doctorid;
    }

    public void setDoctorid(String Doctorid) {
        this.Doctorid = Doctorid;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public Date getPdate() {
        return Pdate;
    }

    public void setPdate(Date Pdate) {
        this.Pdate = Pdate;
    }
    String opd,Pid,Fname,Sname,Gender,Mstatus,Address,City,PhoneNo,Doctorid;

    public String getOpd() {
        return opd;
    }

    public void setOpd(String opd) {
        this.opd = opd;
    }

    public PatientPojo(String Pid, String Fname,String Sname, int age,String opd, String Gender, String Mstatus,Date Pdate, String Address, String City, String PhoneNo, String Doctorid) {
        this.opd =opd;
        this.Pid = Pid;
        this.Fname = Fname;
        this.Sname = Sname;
        this.Gender = Gender;
        this.Mstatus = Mstatus;
        this.Address = Address;
        this.City = City;
        this.PhoneNo = PhoneNo;
        this.Doctorid = Doctorid;
        this.age = age;
        this.Pdate = Pdate;
    }
    int age;
    Date Pdate;
}
