/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package UserDao;

import DBConnection.DBConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import userPojo.DoctorPojo;
import userPojo.PatientPojo;

/**
 *
 * @author HP
 */
public class PatientDao {
    
    public static boolean addPatient(PatientPojo p) throws SQLException
    {
        Connection conn = DBConnection.getConnection();
        PreparedStatement ps = conn.prepareStatement("insert into patients values(?,?,?,?,?,?,?,?,?,?,?,?)");
        ps.setString(1,p.getPid());
        ps.setString(2,p.getFname());
        ps.setString(3,p.getSname());
        ps.setInt(4,p.getAge());
        ps.setString(5,p.getOpd());
        ps.setString(6,p.getGender());
        ps.setString(7,p.getMstatus());
        ps.setDate(8,p.getPdate());
        ps.setString(9,p.getAddress());
        ps.setString(10,p.getCity());
        ps.setString(11,p.getPhoneNo());
        ps.setString(12,p.getDoctorid());
        
        int x = ps.executeUpdate();
        
        return x==1;
        
    }

  public static String getNewId()throws SQLException
  {
      Connection conn= DBConnection.getConnection();
      Statement s = conn.createStatement();
      ResultSet rs = s.executeQuery("select max(p_id) from patients");
      int id = 1;
      if (rs.next()&& rs.next())
      {
          
          String empid = rs.getString(1);
          System.out.println(empid.substring(1));
          int eno =Integer.parseInt(empid.substring(1));
          id=id+eno;
          String st ="P"+id;
          return st;
  }
      else return "P101";
  }
  public static ArrayList<PatientPojo> getAllPatients() throws SQLException
  {
       Connection conn= DBConnection.getConnection();
        Statement s = conn.createStatement();
         ResultSet rs = s.executeQuery("select * from patients");
         ArrayList<PatientPojo>patlist = new ArrayList();
         
         while(rs.next())
         {
             PatientPojo p = new PatientPojo(rs.getString(1),rs.getString(2),rs.getString(3),rs.getInt(4),rs.getString(5),rs.getString(6),rs.getString(7),rs.getDate(8),rs.getString(9),rs.getString(10),rs.getString(11),rs.getString(12));
             patlist.add(p);
         }
         return patlist;
  }
  public static HashMap<String, PatientPojo> AllPatients() throws SQLException
    {
     
      HashMap<String , PatientPojo> p = new HashMap();
     Connection conn = DBConnection.getConnection();
     String qry = "select * from patients";
     Statement st = conn.createStatement();
     ResultSet rs = st.executeQuery(qry);
     while(rs.next()){
         String id = rs.getString(1);
         PatientPojo pp = new PatientPojo(id,rs.getString(2),rs.getString(3),rs.getInt(4),rs.getString(5),rs.getString(6),rs.getString(7),rs.getDate(8),rs.getString(9),rs.getString(10),rs.getString(11),rs.getString(12));
           p.put(id,pp);
     }
     return p;
    }
  public static PatientPojo allPatientDetails(String pid) throws SQLException
  {
      Connection conn = DBConnection.getConnection();
        PreparedStatement ps = conn.prepareStatement("select * from patients where p_id = ?");
        ps.setString(1, pid);
        ResultSet rs = ps.executeQuery();
        rs.next();
        PatientPojo pp = new PatientPojo(rs.getString(1),rs.getString(2),rs.getString(3),rs.getInt(4),rs.getString(5),rs.getString(6),rs.getString(7),rs.getDate(8),rs.getString(9),rs.getString(10),rs.getString(11),rs.getString(12));
          return pp;
        
      
  }
  public static boolean updatePatient(PatientPojo p) throws SQLException
  {
      Connection conn = DBConnection.getConnection();
        PreparedStatement ps = conn.prepareStatement("update patients set f_name =?,s_name =?,age =?,OPD=?,gender=?,m_status =?,p_date =?,address = ?,city =?, phone_no=? ,doctor_id =? where p_id =?");
        
        ps.setString(1,p.getFname());
        ps.setString(2,p.getSname());
        ps.setInt(3,p.getAge());
        ps.setString(4,p.getOpd());
        ps.setString(5,p.getGender());
        ps.setString(6,p.getMstatus());
        ps.setDate(7,p.getPdate());
        ps.setString(8,p.getAddress());
        ps.setString(9,p.getCity());
        ps.setString(10,p.getPhoneNo());
        ps.setString(11,p.getDoctorid());
        ps.setString(12,p.getPid());
        int x = ps.executeUpdate();
        
        return x==1;
  }
}