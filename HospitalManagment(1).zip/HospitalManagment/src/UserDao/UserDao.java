/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package UserDao;

import DBConnection.DBConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import userPojo.UserPojo;

/**
 *
 * @author HP
 */
public class UserDao {
    
    
    public static String validateUser(UserPojo user) throws SQLException
  
    {
        try{
        
      
        Connection conn= DBConnection.getConnection();
        String qry = "select username from users where userid=? and password =? and usertype =?";
        PreparedStatement ps;
        ps = conn.prepareStatement(qry);
        ps.setString(1,user.getUserId());
        ps.setString(2, user.getPassword());
        ps.setString(3,user.getUsertype());
        
        ResultSet rs = ps.executeQuery();
        String username = null;
        if (rs.next())
        {
            username= rs.getString(1);
            
        }
        return username;
        }
        catch (SQLException e)
        {
            return "";
        }
        
        
    }
    public static boolean changePassword(String userid,String pwd) throws SQLException
    {
       
        PreparedStatement ps =DBConnection.getConnection().prepareStatement("update users set password = ? where userid = ?");
            ps.setString(1,pwd);
               ps.setString(2,userid);
               return(ps.executeUpdate()!=0);
    }
    public static HashMap<String,String> getReceptionistList() throws SQLException
    {
        Connection conn= DBConnection.getConnection();
        Statement s = conn.createStatement();
        HashMap<String,String> receptionistList = new HashMap();
        ResultSet rs =s.executeQuery("select userid , username from users where usertype = 'RECEPTIONIST' and active='Y'");
        while(rs.next())
        {
            receptionistList.put(rs.getString(1),rs.getString(2));
        }
        return receptionistList;
}
}