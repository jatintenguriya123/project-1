/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package UserDao;

import DBConnection.DBConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import userPojo.EmpPojo;
import userPojo.UserDetails;

/**
 *
 * @author HP
 */
public class ReceptionistDao {
    public static boolean addReceptionist(UserDetails user)throws SQLException
    {
        Connection conn= DBConnection.getConnection();
        String qry ="insert into users values (?,?,?,?,?,'Y')";
        PreparedStatement ps;
        ps = conn.prepareStatement(qry);
        ps.setString(1,user.getUserid());
         ps.setString(2,user.getUserName());
          ps.setString(3,user.getEmpId()); 
          ps.setString(4,user.getPassword());
           ps.setString(5,user.getUserType());
           int x = ps.executeUpdate();
           return x>0;
        
    }
     public static ArrayList<EmpPojo> getAllReceptionist() throws SQLException
     {
         Statement s= DBConnection.getConnection().createStatement();
         ResultSet rs = s.executeQuery("select * from employee where role = 'RECEPTIONIST' and active ='Y'");
         ArrayList <EmpPojo> recepList = new ArrayList();
         while(rs.next())
         {
             EmpPojo ud = new EmpPojo();
             ud.setEmpid(rs.getString(1));
             ud.setEmpname(rs.getString(2));
             ud.setJob(rs.getString(3));
             ud.setSal(rs.getDouble(4));
             recepList.add(ud);
         }
         return recepList;
     }
     public static HashMap<String ,UserDetails> AllReceptionist() throws SQLException
     {
         Statement s= DBConnection.getConnection().createStatement();
         ResultSet rs = s.executeQuery("select * from users where usertype = 'RECEPTIONIST' and active = 'Y'");
         HashMap<String,UserDetails> hm = new HashMap();
        UserDetails ud = new UserDetails();
         while(rs.next())
         {
            String userid = rs.getString(1);
            String username = rs.getString(2);
            String empid = rs.getString(3);
            hm.put(empid, ud);
         }
         return hm;
     }
    public static UserDetails getrcp(String id) throws SQLException
     {
          Connection conn= DBConnection.getConnection();
         String qry = "select * from users where empid =? and active = 'Y'";
         PreparedStatement ps;
         ps = conn.prepareStatement(qry);
         ps.setString(1, id);
         ResultSet rs =ps.executeQuery();
         
         UserDetails e = new UserDetails();
         rs.next();
         e.setUserid(rs.getString(1));
         e.setUserName(rs.getString(2));
         e.setEmpId(rs.getString(3));
         return e;
     }
    public static boolean removeRecep(String emp) throws SQLException
    {
         Connection conn= DBConnection.getConnection();
        String qry2 = "update users set active ='N' where empid =?";
        String qry = "update employee set active ='N' where empid =?";
        PreparedStatement ps;
        ps = conn.prepareStatement(qry);
        ps.setString(1,emp);
        ps.executeUpdate();

        ps = conn.prepareStatement(qry2);
        ps.setString(1,emp);
        
        
       int  x = ps.executeUpdate();
        
        return x==1;
        
    }
}
