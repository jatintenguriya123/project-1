/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package UserDao;

import DBConnection.DBConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import userPojo.DoctorPojo;
import userPojo.UserDetails;

/**
 *
 * @author HP
 */


public class DoctorDao {
    
    public static String getNewId() throws SQLException
    {
        Connection conn= DBConnection.getConnection();
        Statement s = conn.createStatement();
        ResultSet rs = s.executeQuery("select max(Doctorid) from doctors");
        int id = 1;
        rs.next();
        
            String empid =rs.getString(1);
            int eno = Integer.parseInt(empid.substring(1));
            id=id + eno;
        
        String st ="D"+id;
        //System.out.println(st);
        return st;
        
    }
    public static boolean addDoctor(DoctorPojo d) throws SQLException
    {
        PreparedStatement ps=DBConnection.getConnection().prepareStatement("insert into doctors values(?,?,?,?,'Y')");
        ps.setString(1,d.getUserid());
        ps.setString(2,d.getDoctorid());
        ps.setString(3,d.getQualification());
        ps.setString(4,d.getSpecialization());
      
        int x = ps.executeUpdate();
        return x==1;
    }
    public static ArrayList<String> getAllDoctorId() throws SQLException
    {
        ArrayList<String> docId= new ArrayList();
        
        ResultSet rs = DBConnection.getConnection().createStatement().executeQuery("select doctorid from doctors where active = 'Y'");
        while(rs.next())
        {
            docId.add(rs.getString(1));
        }
        return docId;
    }
    
    
    public static HashMap<String, DoctorPojo> getAllDoctor() throws SQLException
    {
        DoctorPojo dp = new DoctorPojo();
     HashMap<String , DoctorPojo> d = new HashMap();
     Connection conn = DBConnection.getConnection();
     String qry = "select * from doctors where active = 'Y'";
     Statement st = conn.createStatement();
     ResultSet rs = st.executeQuery(qry);
     while(rs.next()){
         
          String id = rs.getString(1);
          dp.setUserid(id);
          dp.setDoctorid(rs.getString(2));
          dp.setQualification(rs.getString(3));
          dp.setSpecialization(rs.getString(4));
          dp.setStatus(rs.getString(5));
          d.put(id, dp);
     }
     return d;
        
    }
    public static UserDetails getDoc(String id) throws SQLException{
    Connection conn= DBConnection.getConnection();
         String qry = "select * from users where userid =? and active ='Y'";
         PreparedStatement ps;
         ps = conn.prepareStatement(qry);
         ps.setString(1, id);
         ResultSet rs =ps.executeQuery();
         rs.next();
         UserDetails dp = new UserDetails();
         dp.setUserid(rs.getString(1));
         dp.setUserName(rs.getString(2));
         dp.setEmpId(rs.getString(3));
         dp.setPassword(rs.getString(4));
         dp.setUserType(rs.getString(5));
         return dp;
         
         
    }
    public static boolean removeDoctor(String userid) throws SQLException
    {
        Connection conn= DBConnection.getConnection();
        String qry4 = "select empid from users where userid =?";
        String qry3 = "update employee set active = 'N' where empid=?";
        String qry2 = "update users set active='N' where userid =?";
        String qry = "update doctors set active ='N' where userid =?";
        PreparedStatement ps;
        
        ps =conn.prepareStatement(qry4);
        ps.setString(1, userid);
        ResultSet rs = ps.executeQuery();
        rs.next();
        System.out.println(rs.getString(1)); 
           
        ps = conn.prepareStatement(qry3);
        ps.setString(1, rs.getString(1));
        ps.executeUpdate();
        
        ps = conn.prepareStatement(qry2);
        ps.setString(1,userid);
        ps.executeUpdate();
        
        ps = conn.prepareStatement(qry);
        ps.setString(1,userid);
        int  x = ps.executeUpdate();
        
        return x==1;
    }
    
    public static DoctorPojo getDoctorDetails(String userid) throws SQLException
    {
          Connection conn= DBConnection.getConnection();
         String qry = "select * from doctors where userid =? and active = 'Y'";
         PreparedStatement ps;
         ps = conn.prepareStatement(qry);
         ps.setString(1, userid);
         ResultSet rs =ps.executeQuery();
         rs.next();
         DoctorPojo dp = new DoctorPojo();
         dp.setUserid(userid);
         dp.setDoctorid(rs.getString(2));
         dp.setQualification(rs.getString(3));
         dp.setSpecialization(rs.getString(4));
         
         return dp;
    }
    public static boolean updateDoctor(DoctorPojo d) throws SQLException
    {
        PreparedStatement ps=DBConnection.getConnection().prepareStatement("update doctors set doctorid=?,qualification=?,specialist=? where userid = ? and active = 'Y' ");
        ps.setString(4,d.getUserid());
        ps.setString(1,d.getDoctorid());
        ps.setString(2,d.getQualification());
        ps.setString(3,d.getSpecialization());
      
        int x = ps.executeUpdate();
        return x==1;
    }
    
    
    public static ArrayList <DoctorPojo> getAllDoctors() throws SQLException
    {
         Connection conn= DBConnection.getConnection();
        Statement s = conn.createStatement();
         ResultSet rs = s.executeQuery("select * from doctors where active ='Y'");
         ArrayList<DoctorPojo>DocList = new ArrayList();
         
         while (rs.next())
         {
             DoctorPojo e = new DoctorPojo();
             e.setUserid(rs.getString(1));
             e.setDoctorid(rs.getString(2));
             e.setQualification(rs.getString(3));
             e.setSpecialization(rs.getString(4));
             DocList.add(e);
         }
        
    
         return DocList;
    }
}
