/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package UserDao;

import DBConnection.DBConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import javax.swing.JOptionPane;
import userPojo.EmpPojo;

/**
 *
 * @author HP
 */
public class EmpDao {
    public static String getNewId() throws SQLException
    {
        Connection conn= DBConnection.getConnection();
        Statement s = conn.createStatement();
        ResultSet rs = s.executeQuery("select max(empid) from employee");
        int id = 1;
        rs.next();
        
            String empid =rs.getString(1);
            int eno = Integer.parseInt(empid.substring(1));
            id=id + eno;
        
        String st ="E"+id;
        //System.out.println(st);
        return st;
        
    }
    public static boolean addEmployee(EmpPojo emp) throws SQLException
    {
        
        Connection conn= DBConnection.getConnection();
        String qry = "insert into employee values(?,?,?,?,'Y')";
        PreparedStatement ps;
        ps = conn.prepareStatement(qry);
        ps.setString(1,emp.getEmpid());
        ps.setString(2,emp.getEmpname());
        ps.setDouble(4,emp.getSal());
        ps.setString(3,emp.getJob());
        
       int x = ps.executeUpdate();
       return x==1;
    }
    public static ArrayList <EmpPojo> getAllEmp() throws SQLException
    {
        Connection conn= DBConnection.getConnection();
        Statement s = conn.createStatement();
         ResultSet rs = s.executeQuery("select * from employee where active ='Y'");
         ArrayList<EmpPojo>empList = new ArrayList();
         
         while (rs.next())
         {
             EmpPojo e = new EmpPojo();
             e.setEmpid(rs.getString(1));
             e.setEmpname(rs.getString(2));
             e.setJob(rs.getString(3));
             e.setSal(rs.getDouble(4));
             empList.add(e);
         }
        
    
         return empList;
    
    }
    
    public static boolean removeEmployee(String emp) throws SQLException
    {
      
        Connection conn= DBConnection.getConnection();
        String qry2 = "update users set active = 'N' where empid =? ";
        String qry = "update employee set active = 'N' where empid =?";
        PreparedStatement ps;
        
        ps = conn.prepareStatement(qry2);
        ps.setString(1,emp);
        
        ps.executeUpdate();
        ps = conn.prepareStatement(qry);
        ps.setString(1,emp);
       int  x = ps.executeUpdate();
        
        return x==1;
        
       
    }
 public static HashMap <String ,String> getNonRegisteredReceptionistList() throws SQLException
 {
     Connection conn = DBConnection.getConnection();
     String qry = "select empid,empname from employee where role = 'RECEPTIONIST' and empid not in (select empid from users where usertype = 'RECEPTIONIST' and active='Y') and active ='Y'";
     Statement st = conn.createStatement();
     ResultSet rs = st.executeQuery(qry);
     HashMap<String ,String> receptionist = new HashMap();
     while(rs.next())
     {
         String id = rs.getString(1);
         String name = rs.getString(2);
         receptionist.put(id,name);
     }
     return receptionist;
 }
 
 
     public static HashMap <String ,EmpPojo> getAllEmpList() throws SQLException
 {
     Connection conn = DBConnection.getConnection();
     String qry = "select * from employee where active = 'Y'";
     Statement st = conn.createStatement();
     ResultSet rs = st.executeQuery(qry);
     HashMap<String ,EmpPojo> employee = new HashMap();
     EmpPojo e = new EmpPojo();
     while(rs.next())
     {
         String id = rs.getString(1);
         String name = rs.getString(2);
         String job = rs.getString(3);
         double sala = rs.getDouble(4);
         employee.put(id,e);
     }
     return employee;
 }
     
     
     public static EmpPojo getEmp(String id) throws SQLException
     {
          Connection conn= DBConnection.getConnection();
         String qry = "select * from employee where empid =? and active = 'Y'";
         PreparedStatement ps;
         ps = conn.prepareStatement(qry);
         ps.setString(1, id);
         ResultSet rs =ps.executeQuery();
         
         EmpPojo e = new EmpPojo();
         rs.next();
         e.setEmpid(rs.getString(1));
         e.setEmpname(rs.getString(2));
         e.setJob(rs.getString(3));
         e.setSal(rs.getDouble(4));
         
         return e;
         
         
     }
     public static boolean updateEmployee(EmpPojo emp) throws SQLException
     {
         PreparedStatement ps = DBConnection.getConnection().prepareStatement("update employee set empname = ? ,role = ?,sal = ? where empid = ? and active = 'Y'");
         
         ps.setString(1,emp.getEmpname());
         ps.setString(2,emp.getJob());
         ps.setDouble(3,emp.getSal());
         ps.setString(4,emp.getEmpid());
         
         int x = ps.executeUpdate();
         return x==1;
         
     }
     public static HashMap<String , String>getAllDocList() throws SQLException
     {
          Connection conn = DBConnection.getConnection();
     String qry = "select empid,empname from employee where role = 'DOCTOR' and empid not in (select empid from users where usertype = 'DOCTOR' and active ='Y')";
     Statement st = conn.createStatement();
     ResultSet rs = st.executeQuery(qry);
     HashMap<String ,String> doc = new HashMap();
     while(rs.next())
     {
         String id = rs.getString(1);
         String name = rs.getString(2);
         doc.put(id,name);
     }
     return doc;
     }
     
    
}

